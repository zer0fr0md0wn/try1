import requests

def adminfind(url):
	pages = open('C:\\Appkivy\\adminpage.txt').read().splitlines()
	for page in pageg:
		code = requests.get(url + '/' + page).status_code
		if code == 200:
			open('adminfind.txt', 'a+').write(url + page + '\n')

adminfind('http://testphp.vulnweb.com/')
